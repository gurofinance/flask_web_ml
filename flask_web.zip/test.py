import pandas as pd

df = pd.read_csv('static/csv_file/final_test.csv', encoding='utf-8')

print(df)