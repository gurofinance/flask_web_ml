from flask import Flask , request , render_template ,Response, request
import matplotlib.pyplot as plt
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure
import numpy as np
import random
import io

app = Flask(__name__)


@app.route('/', methods=['GET', 'POST'])
def index(): 
    f_name = "태경"
    return render_template('index.html', second_name = 'KIM' , first_name=f_name)

@app.route('/plot', methods=['GET', 'POST'])
def graph_image():
    fig = Figure()
    axis = fig.add_subplot(1,1,1)
    xs = range(100)
    ys = [random.randint(1,50) for x in xs]
    axis.plot(xs ,ys )
    output = io.BytesIO()
    FigureCanvas(fig).print_png(output)
    return Response(output.getvalue() , mimetype='image/png')

@app.route('/test', methods=['GET', 'POST'])
def chart_test():
    price= [['apple', 'banana' , 'lemon', 'strewberry'] , [1000, 500, 800,1500]]
    plt.plot(price[0], price[1])
    plt.savefig('static/image/price.png')
    return render_template('price.html' , name="과일가격", url="static/image/price.png")

from titanic_logistic import *
@app.route('/density',methods=['GET', 'POST'] )
def density_graph():
    if request.method == 'GET':
        return render_template('density.html', name=None , url=None)
    else:
        column = request.form['column']
        # print(column)
        # density(column)
        plt.hist(train_df[column], bins=15,histtype=u'step',density=True)
        # ax = train_df[column].hist(bins=15, density=True, stacked=True, color='teal', alpha=0.6)
        train_df[column].plot(kind='density', color='red')
        # ax.set(xlabel=column)
        plt.xlabel(column)
        plt.ylabel('Density')
        plt.savefig(f'static/image/Age.png')
        # plt.savefig(f'static/image/Age.png')
        return render_template('density.html', name=column, url=f'static/image/{column}.png')

@app.route('/preprocessing' , methods=['GET', 'POST'])
def data_preprocessing():
    if request.method == "POST":
        final_train , final_test = preprocessing()
        print(final_train)
        print(final_test)
        return "SUCCESS"
@app.route('/read_csv', methods=['GET', 'POST'])
def read_csv():
    df = pd.read_csv('static/csv_file/final_test.csv', encoding='utf-8')
    return  df.to_html()

@app.route('/params/<int:data>', methods=['GET', 'POST'])
def params_test(data):
    index = data
    df = pd.read_csv('static/csv_file/final_test.csv', encoding='utf-8')
    result = df.iloc[index]
    describe = df.describe()
    print(describe)
    return render_template('params_test.html',name =index , result=result )

if __name__ == "__main__":
    app.run(debug=True)